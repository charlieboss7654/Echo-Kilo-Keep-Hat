fx_version 'cerulean'
game 'gta5'

author 'R.Robertson - Echo Kilo Studios'
description 'Keep hat on when in Vehicles!'
version '1.1.0'

client_script 'client.lua'
