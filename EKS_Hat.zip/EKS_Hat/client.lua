local savedHatIndex = -1
local savedHatTexture = -1

CreateThread(function()
    while true do
        Wait(500)
        local ped = PlayerPedId()

        if not IsPedInAnyVehicle(ped, false) then
            local hat = GetPedPropIndex(ped, 0)

            if hat ~= -1 then
                -- Save currently worn hat
                savedHatIndex = hat
                savedHatTexture = GetPedPropTextureIndex(ped, 0)
            else
                -- Clear saved hat if not wearing one
                savedHatIndex = -1
                savedHatTexture = -1
            end
        end
    end
end)

CreateThread(function()
    while true do
        Wait(0)
        local ped = PlayerPedId()

        if IsPedInAnyVehicle(ped, false) then
            if savedHatIndex ~= -1 and GetPedPropIndex(ped, 0) == -1 then
                SetPedPropIndex(ped, 0, savedHatIndex, savedHatTexture, true)
            end
        end
    end
end)
